package binarysearchtreelab;

public class BinarySearchTreeLab {
    public static void main(String[] args) {
        BSTtree tree1 = new BSTtree();
        tree1.insert(59);
        tree1.insert(100);
        tree1.insert(20);
        tree1.insert(200);
//                    59
//                20      100
//                            200
        System.out.println(tree1.root.info);
        System.out.println(tree1.root.right.info);
        System.out.println(tree1.root.right.right.info);
        System.out.println(tree1.root.left.info);

        BSTnode s = tree1.search(200);
        if (s != null){
            System.out.println(s.info);
        } else {
            System.out.println("not found");
        }

        tree1.insert(31);
        tree1.insert(43);
        tree1.insert(150);
        tree1.insert(1911);
        //           59
        //   20             100
        //      31                  200
        //          43         150         1911
        // preorder: 59, 20, 31, 43, 100, 200, 150, 1911
        // inorder: 20, 31, 43, 59, 100, 150, 200, 1911
        // postorder:
        tree1.preorderTraversalIterative();
        System.out.println("");
        tree1.preorderTraversalRecursion(tree1.root);
        System.out.println("");
        tree1.inorderTraversalRecursion(tree1.root);
        System.out.println("");
        tree1.postorderTraversalRecursion(tree1.root);


        //case 1 delete root
        // tree1.deleteByMerging(59);
        // 20
        //     31
        //         43
        //              100
        //                    200
        //                  159    1911
//        System.out.println("\n"+tree1.root.info);
//        System.out.println(tree1.root.right.right.right.info);


        //case 2
//        tree1.deleteByMerging(31);
//        System.out.println("\n" + tree1.root.left.right.info);

        // case 3 : delete 200
        //                59
        //       20               100
        //          31                  150
        //              43                  1911
//        tree1.deleteByMerging(200);
//        System.out.println("\n"+ tree1.root.right.right.info);
//        System.out.println("\n"+ tree1.root.right.right.right.info);

        //                59
        //       20               100
        //          31                  150
        //              43                  1911
        //case 4 delete leaf nnode
        tree1.deleteByMerging(150);
        System.out.println("\n" + tree1.root.right.right.left);
    }

}
